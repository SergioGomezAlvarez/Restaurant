<?php if (isset($_SESSION['login'])) { ?>
                    <a href="logout.php">Logout</a>
                    <span class="scheidingslijn"></span>
                <?php } ?>